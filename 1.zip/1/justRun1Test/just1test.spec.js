const Add = require('./just1test'); // common js

describe("", () => {
    it('should test addition of two numbers', () => {
        // Arrange
        let result;
        // Act
        result = Add(10, 20);
        // Assert
        expect(result).toBe(30);
    });

    it('should test addition of string and numbers', () => {
        // Arrange
        let result;
        // Act
        result = Add(10, "hello");
        // Assert
        expect(result).toBe("30Hello");
    });

    fit('should test addition of string numbers', () => { // here f means focus basically we will only focus this test only and excluding other test.
        // Arrange
        let result;
        // Act
        result = Add("hello", "hurray");
        // Assert
        expect(result).toBe("hellohurray");
    });
})

fdescribe("", () => {
    it('sample test', () => { // it will count this in skipped and passed
        // Arrange
        let result;
        // Act
        result = Add(10, 20);
        // Assert
        expect(result).toBe(30);
    });
})