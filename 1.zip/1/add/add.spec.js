const Add = require('./add'); // common js

describe("", () => {
    it('should test addition of two numbers', () => {
        // Arrange
        let result;
        // Act
        result = Add(10, 20);
        // Assert
        expect(result).toBe(30);
    });

    xit('should test addition of string numbers', () => { // here x means exclude basically we will excluding this test
        // Arrange
        let result;
        // Act
        result = Add("hello", "hurray");
        // Assert
        expect(result).toBe("hellohurray");
    });
})
